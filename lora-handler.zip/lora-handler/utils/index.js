//Import Axios
const Axios = require('axios');
//Import Configs
const { deviceAPI } = require('../config/adaptor');

//All Utils
class Utils {
  getTimeSyncData(data) {
    function ConvertStringToHex(number) {
      if (number < 0) {
        number = 0xffffffff + number + 1;
      }

      return number.toString(16).toUpperCase();
    }

    const index = 0;

    const date = new Date();

    const ts =
      ConvertStringToHex(data.slice(index, index + 2)) +
      ConvertStringToHex(data.slice(index + 2, index + 4).padStart(2, '0')) +
      ConvertStringToHex(date.getFullYear()).padStart(4, '0') +
      ConvertStringToHex(date.getMonth()).padStart(2, '0') +
      ConvertStringToHex(date.getDay()).padStart(2, '0') +
      ConvertStringToHex(date.getHours()).padStart(2, '0') +
      ConvertStringToHex(date.getMinutes()).padStart(2, '0') +
      ConvertStringToHex(date.getSeconds()).padStart(2, '0') +
      ConvertStringToHex(data.slice(index + 4, index + 6));

    return ts;
  }
  getDeviceDetails(macAddress) {
    let url = `${deviceAPI}${macAddress}`;
    return new Promise(function (resolve, reject) {
      Axios.get(url).then(
        (res) => {
          if (res.data.data.code == 20) {
            let response = res.data.data.results;
            resolve(response);
          } else {
            reject('Device api response parse error');
          }
        },
        (err) => {
          console.log('Error: ', err.data);

          reject('Device API fetch error!');
        }
      );
    });
  }
  main(data, devicesCol) {
    let macAddress = data.EUI;

    //Find this device in Loki
    let deviceInLoki = devicesCol.findOne({ macAddress });

    //Get Device Details
    return this.getDeviceDetails(macAddress).then(
      function (deviceDetails) {
        if (deviceDetails) {
          const dDetails = {
            deviceAddress: macAddress,
            macAddress: deviceDetails.macAddress,
            deviceId: deviceDetails.deviceId,
            tenantId: deviceDetails.tenantId,
            appId: deviceDetails.app,
            mfrId: deviceDetails.mfrId,
            devicePort: data.port,
            uniqueKey: deviceDetails.uniqueKeyB64,
          };
          if (deviceInLoki) {
            //console.log(deviceInLoki);
            //Update existing
            //devicesCol.update(dDetails);
            return { deviceDetails: dDetails };
          } else {
            //insert into  db
            devicesCol.insert(dDetails);
            console.info(`Cached ${dDetails.deviceId}!`);
            return { deviceDetails: dDetails };
          }
        } else {
          console.info(`DeviceId:${deviceId} not found`);
        }
      },
      function (err) {
        console.error(err);
      }
    );
  }
}
module.exports = Utils;
