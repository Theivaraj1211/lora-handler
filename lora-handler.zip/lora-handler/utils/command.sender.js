//Import kafka
const Kafka = require("kafka-node");
//Import Config
const {
  kafkaHost,
  kafkaPort,
  kafkaCommandSubTopic,
} = require("./../config/adaptor");
const Producer = Kafka.Producer;
const Consumer = Kafka.Consumer;
const kafkaClient = new Kafka.KafkaClient({
  kafkaHost: `${kafkaHost}:${kafkaPort}`,
  requestTimeout: 50000,
});

const kafkaProducer = new Producer(kafkaClient);

kafkaProducer.on("ready", function () {
  console.info("Kafka is ready");
  kafkaReady = true;
});
const payloads = [
  {
    topic: "loraCommandData",
    messages: JSON.stringify({
      deviceId: "58208A8800DB0000",
      payload: {
        type: "buzzer",
        cmd: "00",
        tId: "00000008",
      },
      ts: 1627018296,
    }),
  },
];
//Send

kafkaProducer.send(payloads, function (err, data) {
  if (err) {
    console.error(err);
  }
  console.info("Data successfully Sent to command topic!", data);
});

//Error
kafkaProducer.on("error", function (err) {
  console.log("Crashed 2", err);
  process.exit(-1);
});
