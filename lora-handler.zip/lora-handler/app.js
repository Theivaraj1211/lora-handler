//Import Axios
const Axios = require('axios');
//Import Settings
const {
  deviceAPI,
  kafkaPublishTopic,
  loraServer,
  loraServerAuthToken,
  loraServerAppId,
} = require('./config/adaptor');
//Import LokiJs
const Loki = require('lokijs');
//Import Utility functions
const UtilClass = require('./utils');
const Utils = new UtilClass();
//Import Kafka
const { kafkaProducer, kafkaConsumer } = require('./utils/kafka');
//Creating the local db:
const db = new Loki('lora_handler_db_local');
// Add a collection to the database
const lokiDevices = db.addCollection('devices');

module.exports = class APIHandler {
  //Get Lora Device data
  static loraHandler = async (ctx, next) => {
    //Get request body
    const input = ctx.request.body;
    if (input.cmd == 'rx' && input.EUI) {
      console.log(JSON.stringify(input));
      try {
        //Validate Device
        const response = await Utils.main(input, lokiDevices);
        //Time Sync
        if (input.data == 'ff00ff') {
          console.log("<==== Time Sync request received ===>", new Date())
          const data = Utils.getTimeSyncData(input.data);
          let url = `${loraServer}`;
          const postData = {
            cmd: 'tx',
            EUI: input.EUI,
            port: 2,
            confirmed: true,
            data: data,
            appid: loraServerAppId,
          };
          let axiosConfig = {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${loraServerAuthToken}`,
            },
          };
          postData.data = "ff1007e607010d3826ff";
          console.log(JSON.stringify(postData));
          //Send command
          try{
              const response = await Axios({
                method: "POST",
                url,
                headers: {
                  Authorization: `Bearer ${loraServerAuthToken}`,
                },
                data: postData
              });
           console.log('RESPONSE SENT TO DEVICE: ', JSON.stringify(response.data));
            console.log("<==== Time Sync response sent ===>", new Date())
          }catch(err){
            console.log('AXIOS ERROR: ', JSON.stringify(err.response));
          }
        } else {
          //Get Device details
          const deviceDetails = response.deviceDetails;
          console.log(deviceDetails.deviceId, input.data);
          //Prepare kafka message
          let kafkaMessages = {
            protocol: deviceDetails.protocolType,
            deviceId: deviceDetails.deviceId,
            tenantId: deviceDetails.tenantId,
            appId: deviceDetails.appId,
            dataFrom: deviceDetails.deviceId,
            ingestTimestamp: new Date().getTime(),
            rawData: input.data,
            mfr: deviceDetails.mfrId,
            //packetSize: input.data.length,
            packetSize: 0,
          };
          // convert JSON object to String
          let jsonKStr = JSON.stringify(kafkaMessages);
          //Pass the data to transformer
          const kafka_data = {
            topic: kafkaPublishTopic,
            messages: jsonKStr,
          };
          //console.log(kafka_data);
          kafkaProducer([kafka_data]);
          //Response
          ctx.status = 200;
          ctx.body = { success: true };
          return ctx.body;
        }
      } catch (err) {
        console.log(err);
      }
    } else {
      //console.log("Skipping____", input);
      //Response
      ctx.status = 200;
      ctx.body = {
        success: true,
        msg: 'Skipped and not included for transformation!',
      };
      return ctx.body;
    }
  };
};
