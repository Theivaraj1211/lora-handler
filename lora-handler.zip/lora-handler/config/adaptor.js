/*jshint esversion: 8 */
const path = require("path");
//Get all the settings
const setting = require("./settings.dev");

module.exports = {
  appName: "4S Lora Handler",
  env: setting.appEnv,
  port: setting.appPort,
  logs: setting.appLog,
  //ip:'localhost', //This will not let app accesible on LAN
  ip: setting.appHost,

  root: path.normalize(`${__dirname}/../..`), // root
  base: path.normalize(`${__dirname}/..`), // base

  logFileName: {
    info: "info.log",
    error: "exceptions.log",
  },
  db: {
    pg: {
      // PGSQL - Sample URI
      // uri: 'postgres://user:pass@example.com:5432/dbname'
      uri: (() => {
        //If Username Password is set
        if (setting.pgdbIsAuth === "true") {
          return `postgres://${setting.pgdbUsername}:${setting.pgdbPassword}@${setting.pgdbHost}:${setting.pgdbPort}/${setting.pgDbName}`;
        }
        //Without auth
        return `postgres://${setting.pgdbHost}:${setting.pgdbPort}/${setting.pgDbName}`;
      })(),

      masterDb: `${setting.pgDbName}`,
      options: {},
      host: setting.pgdbHost,
      port: setting.pgdbPort,
      username: setting.pgdbUsername,
      password: setting.pgdbPassword,
    },
  },
  iotPFAppToken: setting.iotPFAppToken,
  iotPFDSAPI: setting.iotPFDSAPI,
  deviceAPI: setting.deviceAPI,
  kafkaHost: setting.kafkaHost,
  kafkaPort: setting.kafkaPort,
  kafkaPublishTopic: setting.kafkaPublishTopic,
  kafkaStatusPublishTopic: setting.kafkaStatusPublishTopic,
  kafkaCommandSubTopic: setting.kafkaCommandSubTopic,
  loraServer: setting.loraServer,
  loraServerAppId: setting.loraServerAppId,
  loraServerAuthToken: setting.loraServerAuthToken,
};
