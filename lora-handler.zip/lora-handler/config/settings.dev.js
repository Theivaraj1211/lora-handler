module.exports = {
  appEnv: process.env.NODE_ENV || 'dev',
  appLog: process.env.APP_LOG || 'dev',
  appPort: process.env.SSSS_LORA_HANDLER || 9002,
  appHost: '0.0.0.0',

  deviceAPI:
    process.env.DATA_HANDLER_DEVICE_IDENTITY_API ||
    'http://iot.hyperthings.in:17012/device/',
  kafkaHost:
    process.env.DATA_HANDLER_KAFKA_HOST ||
    process.env.KAFKA_HOST ||
    'iot.hyperthings.in',
  kafkaPort:
    process.env.DATA_HANDLER_KAFKA_PORT || process.env.KAFKA_PORT || '17002',
  kafkaPublishTopic:
    process.env.DATA_HANDLER_KAFKA_TOPIC_PUB || 'dataHandlerData',
  kafkaStatusPublishTopic:
    process.env.DATA_HANDLER_KAFKA_STATUS_TOPIC_PUB || 'statusData',
  kafkaCommandSubTopic:
    process.env.DATA_HANDLER_LORA_KAFKA_COMMAND_TOPIC_SUB || 'statusData',
  loraServer: process.env.SSSS_LORA_SERVER || 'https://lns2.connectedworkers-ksa.com/1/rest',
  loraServerAppId: process.env.SSSS_LORA_APPID || 'BE010006',
  loraServerAuthToken:
    process.env.SSSS_LORA_SERVER_AUTH_TOKEN ||
    'vgEABgAAAB1sbnMyLmNvbm5lY3RlZHdvcmtlcnMta3NhLmNvba5MDjcVjS9zzQbuLIYjl_8=',
};
