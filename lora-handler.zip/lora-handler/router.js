"use strict";
//Import Koa Router
const Router = require("koa-router");
//Instantiate Router
const router = new Router();
//Import Controller
const Controller = require("./app");

//Lora Handler
router.post("/lora-handler", Controller.loraHandler);

//Export
module.exports = router;
